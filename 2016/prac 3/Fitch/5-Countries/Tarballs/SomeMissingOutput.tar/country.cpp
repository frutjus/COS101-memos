#include <string>
#include <iomanip>
#include <fstream>
#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	ifstream myfile;
	cout<<"Give the file name: ";
	string filename;
	cin>>filename;
	myfile.open(filename.c_str());
	int counter=1;
	
	if (myfile.fail())
	cout<<"File does not exist!";
	
	else if (!myfile.fail())
	{
		int comparison=9999999;
		string textline, smallestCountry;
		double number;
		cout<<"------------------------------------------------------\n";
		while((myfile>>textline)&&(myfile>>number))
		{
		cout<<right<<setw(3)<<counter<<"  "<<left<<setw(30)
			<<textline<<right<<setw(10)<<round(number)<<endl;
		counter+=1;
			if (number<comparison)
			{
			smallestCountry=textline;
			comparison=number;	
			}	
		}
		
		if (counter<2) 
		cout<<filename<<" is empty";
		else
		{
		cout<<"------------------------------------------------------\n"
		<<"The smallest country on this list is: " <<smallestCountry<<endl;
		}	
	}
	
}