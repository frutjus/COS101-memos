#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
	time_t mySeed;
	cout<<"Give a seed value: ";
	cin>>mySeed;
	srand(time(&mySeed)); //the ampersand makes the value of myseed in the time function the value of mySeed
	cout<<"Number of questions: ";
	int noQuestions, myint, uCorrect,myCounter=0;
	cin>>noQuestions;
	myCounter=noQuestions;
	myint=1;
	uCorrect=0;
		while (myCounter>0)
		{
			int noOne, noTwo, uAnswer, cAnswer ;
			noOne=(rand()%90)+10;
			noTwo=(rand()%90)+10;
			cAnswer=noOne+noTwo;
			cout<<myint<<".\t"<< noOne<<" + "<<noTwo<< " = ";
			cin>>uAnswer;
			if (uAnswer==cAnswer)
				{
				cout<<"Yes. Your answer is correct\n";
				uCorrect++;
				}
					else
					{
					cout<<"No. Your answer is " <<uAnswer<< ". The correct answer is " << cAnswer <<endl;
					}
			myCounter--;
			myint++;		
		}
	cout<<"------------------------------------------"<<endl<<"You scored " << uCorrect << " / " << noQuestions<<endl;
	
	return 0;
}