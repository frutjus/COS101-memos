#include <iostream>
using namespace std;

int main()

{

	cout << "--------------------------------" << endl;
	cout << "This is COS132." << endl;
	cout << "My Student number is u15305792." << endl;
	cout << "--------------------------------" << endl;

return 0;

}
