#include<iostream>
#include<iomanip>
#include<cmath>

using namespace std; 

int main()
{
	cout<< "This is a fraction calculator"<<endl;
	cout<< "**********************" <<endl;
	
	 double a,b,c,d;
	 double answer,div1,div2; 
	
	
	cout<< " FIRST FRACTION "<<endl;
	cout<< "  Enter the numerator: ";
	cin>>a;
	cout<<"  Enter the denominator: ";
	cin>>b;
	div1=a/b;
	cout<<" SECOND FRACTION "<<endl;
	cout<<"  Enter the numerator: " ;
	cin>>c;
	cout<<"  Enter the denominator: " ;
	cin>>d;
	
	div2=c/d;
	
	answer=div1+div2;
	
	cout<<showpoint << setprecision(2)<<fixed;

	cout<<a<<"/"<<b<<" + "<<c<<"/"<<d<<" = " ;
	cout<<answer<<endl;
	return 0;	
}

