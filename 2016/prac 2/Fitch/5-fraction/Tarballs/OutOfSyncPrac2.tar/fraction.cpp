#include<iostream>
#include<iomanip>
using namespace std;

int main()

{
	double numerator1,numerator2, denominator1,denominator2, fraction1, fraction2, answer;
	cout << "This is a fraction calculator" << endl;
	cout << ".............................." << endl;
	cout << "FIRST FRACTION" << endl;
	cout << "  Enter the numerator: ";
        cin >> numerator1;
	cout <<  endl;
	cout << "  Enter the demoninator: ";
         cin >> denominator1;
         cout << endl;	
	fraction1 = numerator1/denominator1;
	
	cout << "SECOND FRACTION" << endl;
	cout << "  Enter the numerator: "; 
        cin >> numerator2;
	cout << endl;
	cout << "  Enter the demoninator: ";
         cin >> denominator2;
         cout << endl;	
	fraction2 = numerator2/denominator2;
	
	answer = fraction1 + fraction2;
	
	cout << numerator1<< "/" << denominator1 << " + "  <<  numerator2 << "/" << denominator2<< " = " <<fixed<<setprecision(2)<< answer << endl;
return 0;

}
	
	
	
	
	