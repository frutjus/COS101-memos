#include <iostream>
using namespace std;

const double SPEED = 120.0;

int main()
{
    double time;
    cout << " Enter the hours traveled: ";
    cin >> time;
    cout << " The drone travelled " <<time*SPEED<< "km in " <<time<< " hours."<< endl;
    
    return 0;
    
}

