#include <iostream>		
#include <iomanip>
using namespace std;

const double SPEED = 120.0; 
	
int main()				
{
	float hours,distance;
	cout<<"Enter the hours traveled:";
	cin>>hours;
	distance = hours*SPEED;
	cout<<"The drone traveled "<<setprecision(2)<<fixed<<distance<<" km in "<<hours<<" hours.\n";

	return 0;
}
