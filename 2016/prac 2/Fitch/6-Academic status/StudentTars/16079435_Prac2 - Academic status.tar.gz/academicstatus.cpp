#include <iostream>
 using namespace std;
 int main()
 {
	 int mark;
	 
	 cout << "Enter your mark: ";
	 cin >> mark;
	 
	 
	 if ( mark >= 75 )
		 cout << "Congratulations! Having a " << mark << " means you have passed with a distinction." << endl;
	 else if ( mark >= 50 )
		 cout << "Well done. Having a " << mark <<" means you pass." << endl;
	 else if ( mark >= 40 )
		 cout << "Having a "<< mark <<" means you qualify for a supplementary exam." << endl;
	 else if ( mark < 40 )
		 cout << "Having a "<< mark <<" means you have failed." << endl;
	  
	return 0;
 }