#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	int mark;
	cout<<"Enter your mark:";
	cin >> mark;
	
	if ((mark >= 75) && (mark <= 100))
	{
		cout << "Congratulations! Having " << mark << " you pass with a distinction.\n";
	}
	else if ((mark  >= 50)  && (mark <= 74))
	{
		cout << "Well done. Having " << mark << " you pass.\n";
	}
	else if ((mark >= 40) && (mark<=49))
	{
		cout << "Oops!. Having " << mark << " you must do a re-exam.\n";
	}
	else if ((mark < 40) && (mark >= 0)) 
	{
		cout << "Oops. Having " << mark << " you fail.\n";
	}
	else 
	{
	cout << "Number cant be a negative and number cant exceed 100\n";
	}
	
	return 0;
}