#include <iostream>
using namespace std;

int main()
{
	int mark;
	
	cout << "Enter your mark: ";
	cin >> mark;
	
	if (mark>100)
		cout<<"Your mark can't be higher then 100. Please rerun the program and enter another value.";
	else if (mark >= 75)
		cout << "Congradulations! Having " << mark << " you pass with distinction.\n";
	else if (mark >= 50)
		cout << "Well done. Having " << mark << "  you pass.\n";
	else if (mark >= 40)
		cout << "Sorry. Having " << mark << " requires you to admitt to a re-exam.\n";
	else if ((mark<40)&&(mark>=0))
		cout << "Very sorry. Having " << mark << " you fail.\n";
	else if (mark<0)
		cout<<"Your mark can't be less than 0. Please rerun the program and type in a different value.";
	else
		cout << "Your value is not valid. Please rerun the program and type in a different program.";
	
	return 0;
}