#include <iostream>

using namespace std;

int main()
{
	
	int marks;
	cout <<"Enter your mark: ";
	cin>>marks;
	

   if(marks>100)
     cout<<"Invalid input"<<endl;
     else
	if ((marks<=100)&&(marks>=75))
		cout<<"Congratulations! you got  " <<marks<<"% you pass with a distinction."<<endl;
	     else
		 if ((marks>=50)&&(marks<=74))
			 cout<<"Well done. you got " <<marks<<"% you passed."<<endl;
			else
				if((marks>=40)&&(marks<=49))
				cout<<"you got " <<marks<<"%"<<" Admitted to re-exam."<<endl;
				else 
					if((marks<=100)&&(marks>=0))

					cout <<"you got "<<marks<<"% You Failed."<<endl;
								
			
			

	
		 
	return 0;
}