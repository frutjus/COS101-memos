#include<iostream>
#include<iomanip>

using namespace std; 

int main()
{
	cout << "Enter your mark: ";
	
	int mark;
	cin >> mark;

	if (cin.fail())
	{
		cout << "Please enter a valid mark." << endl;
	}	
	else if (mark > 100)
	{
		cout << "Please enter a valid mark between 0 and 100." << endl;
	}
	else if (mark >= 75)
	{
		cout << "Congratulations! Having " << mark << " you pass with distinction." << endl;
	} 
	else if (mark >= 50)
	{
		cout << "Well done. Having " << mark << " you pass." << endl;
	}
	else if (mark >= 40)
	{
		cout << "Almost. Having " << mark << " you are admitted to re-exam." << endl;
	} 
	else if (mark >= 0)
	{
		cout << "Oh no. Having " << mark << " you fail." << endl;
	}
	else
	{
		cout << "Please enter a valid mark between 0 and 100." << endl;
	}	
	
	return 0;	
}

