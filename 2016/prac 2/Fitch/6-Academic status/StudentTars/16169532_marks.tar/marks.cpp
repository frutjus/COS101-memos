#include <iostream>
using namespace std;

int main()
{
cout << "Enter your mark: ";
unsigned short int mark;
cin  >> mark;

if(mark > 100)
  {
  cout << "Invalid mark - An overflow/underflow might have occured\n";
  return 0;
  }

if(mark >= 75)
	cout << "You pass with a distinction!";
if(mark >= 50 && mark <= 74)
	cout << "You pass!";
if(mark >= 40 && mark <= 49)
	cout << "You have been admitted to re-exam!";
if(mark < 40)
	cout << "You have failed!";
cout << '\n';
return 0;
}
