#include<iostream>
 using namespace std;
 const int  ASCORE = 75,
		BSCORE = 50,
		CSCORE = 40;

 
 int main()
 
 {
	 int mark;
	 cout << "Enter your mark:";
	 cin >> mark;
	 
	if(mark > 100)
		cout << "The mark you have entered is invalid. \n";
	else if(mark < 0)
		cout << "The mark you have entered is invalid. \n";
	 else if(mark >= ASCORE)
		 cout <<"Your mark is: " <<mark<< ". Congratulations! That is a distinction. \n";
	 else if(mark>=BSCORE)
		 cout <<"Your mark is: " <<mark<< ". This is a pass. \n";
	 else if(mark >= CSCORE)
		 cout <<"Your mark is: " <<mark<< ". You qualify for a rewrite. \n";
	 else
		 cout << "Your mark is: " <<mark<< ". You have failed. \n";
			
	
		 return 0;
	 
	 }
