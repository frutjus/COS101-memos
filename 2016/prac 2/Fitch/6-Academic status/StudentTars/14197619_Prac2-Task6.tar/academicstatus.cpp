#include <iostream>
using namespace std;
int main()

{
int mark;
cout<<"Enter your mark: ";
cin>>mark;

if (mark>100 || mark<0) cout<<"Invalid"<<endl;

else if (mark>=75) 
   cout<<"Congratulations! a(n) "<<mark<<" is a pass with distinction."<<endl;

else if ((mark>=50) && (mark<=74))
        cout<<"Well done. a(n) "<<mark<<" is a pass."<<endl;

else if ((mark>=40 ) && (mark<=49))
	    cout<<"Having "<<mark<<"  means you have been admitted to re-exam."<<endl;

else cout<<"Sorry, "<<mark<<" is a fail."<<endl;

return 0;
	
}
