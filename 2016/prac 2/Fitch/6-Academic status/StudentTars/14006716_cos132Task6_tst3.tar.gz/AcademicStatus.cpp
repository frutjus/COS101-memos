#include <iostream>		
#include <iomanip>
using namespace std;

const unsigned short DIST = 75;
const unsigned short PASS = 50;
const unsigned short ADMITTED = 40;
	
int main()				
{
	int mark = 0.0;
	
	cout << "Enter your mark: ";
	cin >> mark;
	if (!cin.good()) {
	  cout << "Not a valid mark, rerun and try again.\n";
	  return 1;
	}
	if (mark>100)
	  mark = 100;
	else if (mark < 0)
	  mark =0;
	
	if (mark < ADMITTED)
		cout << "Try harder next time. Having "<< mark << " you fail.\n";
	else if (mark < PASS)
		cout << "Study hard! Having "<< mark << " you are admitted to re-exam\n";
	else if (mark < DIST)
		cout << "Well done. Having "<< mark << " you pass\n";
	else
		cout << "Congratulations!! Having "<< mark << " you pass with distinction\n";
	return 0;
}
