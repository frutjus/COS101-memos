#include <iostream>
#include <iomanip>
#include<cmath>
using namespace std;
 int main()
 {
	 double mark;
	 
	 cout << "Enter your mark: ";  

	 cin >> mark;
	 const int A_score= 75,
			B_score = 74,
			C_score = 50,
			D_score = 49,
			E_score = 40,
			F_score =100,
			G_score = 0;
		
	 
	 if ( mark >= A_score && mark <= F_score)
	 {
		 cout << "Congratulations! Having " << mark << " you pass with distinction." << endl;
	 }
	 else if ( C_score <= mark && mark <= B_score)
	 {
		 cout << "Well done. Having " << mark << " you pass." << endl;
	 }
	 else if  ( E_score <= mark && mark <= D_score)
	 {
		 cout << "Having " << mark << " Admits you to re-exam" << endl;
	 }
	 else if ( mark > 100)
	 {
		 cout << "Invalid score" << endl;
	 }
	 else if ( mark < 0)
	 {
		 cout << "Can not have a neagtive score" << endl;
	 }
	 else 
	 {
		 cout << "Sorry having " << mark <<  " means you fail" << endl;
	 }
	 
	 return 0;
 }
	 