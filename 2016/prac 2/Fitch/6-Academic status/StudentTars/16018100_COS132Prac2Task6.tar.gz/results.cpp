#include <iostream>
using namespace std;

int main()
{
	int result;
	
	cout << "Enter your mark: ";
	cin >> result;
	
	if (result > 100 || result < 0)
		cout << "Invalid percentage.";
	else if (result >= 75)
		cout << "Excellent! You achieved " << result << " and pass with a distinction.";
	else if (result >=50)
		cout << "Well done! Having " << result << " you pass.";
	else if (result >= 40)
		cout << "With " << result << " you are admitted to re-exam.";
	else
		cout << "Sorry, having " << result << " you have failed the year.";
	
	cout << "\n";
	return 0;
}