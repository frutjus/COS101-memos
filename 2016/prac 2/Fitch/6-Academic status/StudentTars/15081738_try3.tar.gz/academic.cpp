#include <iostream>
#include<iomanip>

using namespace std;
int main()

{
    int mark;
    
    cout << "Enter your mark: " ;
    cin >> mark;
    
    if ( mark >= 75 && mark<=100)
    {
        cout << "Congratulations! Having " << mark << " you pass with a distinction." << endl;
    }
    
    else if (mark>=50 && mark<=74)
    {
        cout << "Well done. Having " << mark << " you pass." << endl;
    }
    
    else if (mark >=40 && mark <=49)
    {
        cout << "Unforfunately, having " << mark << " you are admitted to re-exam. This is your last chance to pass, make use of it! " << endl;
    }
    
    else if (mark>=0 && mark<=39)
    {
        cout << "Very sorry. Having " << mark << " you have failed. Please work harder next year." << endl;
    }
    else if (mark < 0)
    {
	    cout << mark << " is a negative number, your mark cannot be less than 0! " << endl;
    }
    else
    {
	    cout << mark << " is more than 100, that is not possible! " << endl;
    }
    
    return 0;
    
}