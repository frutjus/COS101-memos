//The following program will determine the academic status of a COS132 student

#include<iostream>
#include<math.h>

using namespace std;

int main()
{
//Variable declarations
	double mark;
	
	
	cout<<"Enter your mark: ";
	cin>>mark;
	
	if(cin.fail())
		mark = -1;
	
	mark = round(mark);
	
	
	
	
if(mark >=0 && mark <=100  && mark)
{	
	if (mark >= 75)
		cout<<"Exccelent!! With a mark of "<<mark<<"  you have earned yourself a distinction!";
	else if (mark>=50  &&  mark<= 74)
		cout<<"Nice work!! With a mark of "<<mark<<", you have passed this module!";
	else if (mark>=40 && mark<=49)
		cout<<"Unfortutely you failed with "<< mark << ", but you are admitted to a re-exam.";
	else if (mark<40)
		cout<<"You failed this module with "<<mark<<", please try again next semester!";
}
	
	return 0;
	
}