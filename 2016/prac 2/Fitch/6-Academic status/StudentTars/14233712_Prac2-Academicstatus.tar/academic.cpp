/* Mmathapelo Matsobe
	u14233712
	Practical 2
	Task6
*/

#include <iostream>
using namespace std;

int main()
{
	double mark;
	
	cout << "Enter your mark: ";
	cin>>mark;
	
	if (mark<40)
		cout << "Sorry. With "<< mark <<"% you failed COS132."<<endl;
	
	else if (mark>=40 && mark<=49)
		cout << "Sorry. With " << mark <<"% you are admitted to re-exam."<<endl;
	else if (mark>=50 && mark<=74)
		cout <<"Well done. With "<<mark<<"% you passed COS132."<<endl;
	else if (mark>=75 && mark<=100)
		cout <<"Cogratulations. With "<<mark<<"% you have passed COS132 with a distinction."<<endl;
	else 
		return 0;
};