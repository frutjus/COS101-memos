// Programming task 6: Academic status [17]

#include <iostream>
using namespace std;

int main()
{
	int mark ;
	;cout << "Enter your mark: ";
	cin >> mark ;
	
	if (mark >= 75 && mark <=100)
		cout<< "Excellent! Having " << mark << " you pass with distinction." << endl;
		
	else if (mark >=50 && mark <=74)
		cout << "Good job! Having " << mark << " you pass." << endl;
	
	else if (mark >=40 && mark <=49)
		cout << "You have another chance. Having " << mark << " you are admitted to re-exam." << endl;

		
	else if (mark <=39 && mark >=0)
		cout << "You should have worked harder. Having " << mark << " you fail." <<endl;
		
	else if (mark <0 || mark >100);

	return 0;
	
}