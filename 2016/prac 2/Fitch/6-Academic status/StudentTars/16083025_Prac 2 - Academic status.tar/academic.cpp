// Header Files
#include <iostream>

using namespace std;

int main ()
{
  //Defining Variables
  int student_mark;

  cout << "Enter your mark: ";
  cin >> student_mark;


  //If statements.
  if (student_mark > 100)
    { cout << "Value out of range, please enter a value within range\n";
    }
  else if (student_mark < 0 )
  { cout << "Value out of range, please enter a value within the range.\n" ;
  }
  else if (student_mark >= 75 && student_mark <=100)
    {
    cout << "You have achieved " << student_mark << " congratulations you pass with a distinction.\n";
    }

	   else if (student_mark >= 50 && student_mark <=74)
  	  {
   	  cout << "You have acheived " << student_mark << " well done, you pass.\n";
 	    }

		    else if (student_mark >= 40 && student_mark <= 49)
  		      {
   		       cout << "Having achieved " << student_mark << " you are admitted to re-exam.\n";
  		      }

			       else if (student_mark < 40)
 			          {
  			        cout << "Having achieved " << student_mark << " you have unfortunately failed.\n";
 			          }

  return 0;

}
