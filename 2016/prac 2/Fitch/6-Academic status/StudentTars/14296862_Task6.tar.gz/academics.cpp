//u14296862

#include<iostream>
#include<iomanip>

using namespace std;

int main()

{
	
	double mark;
	

	cout << "Enter your mark: ";
	cin >> mark;

	if(mark<=100 && mark>= 75)
	 {

		cout << "Congratulations! Having " << mark << " you pass with distintion. " <<endl;
	 }
	else if(mark<75 && mark>=50)

	{	
		cout << "Welldone! Having " << mark << " you pass. " <<endl;

	}

	else if(mark<50 && mark>=40)
	{
		cout << "You are admitted to the re-examination with your " << mark << endl;
	}
	else if(mark<40 && mark>=0)
	{
		cout << "You do not meet the requirements with a mark of " << mark << ". You have therefore failed ." << endl;

	}
	
	else if(mark>100)
	{
		cout << "Error. Mark cannot be bigger than 100. " << endl;
	}

	else if(mark<0)
	{
		cout << "Error. Mark cannot be negative. " << endl;
	}
	else 
	{
		cout << "Error. Mark is not a number. " <<endl;
	}

	
	
return 0;
	

}	
