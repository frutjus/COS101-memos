#include <iostream>
#include <iomanip>
using namespace std;

int main(){
    double mark;
    
    cout<<"Enter your mark: ";
    cin>>mark;
    
    if(mark<40 && mark>=0){
        cout<<"Sorry. Having "<<setprecision(2)<<fixed<<mark<<" indicates that you have failed."<<endl;
    }
    if(mark>=40 && mark<50){
        cout<<"Having "<<setprecision(2)<<fixed<<mark<<" re-admits you to the exam."<<endl;
    }
    if(mark>=50 && mark<75){
        cout<<"Well done. "<<setprecision(2)<<fixed<<mark<<" indicates that you have passed."<<endl;
    }
    if(mark>=75 && mark<=100){
        cout<<"Congradulations! "<<setprecision(2)<<fixed<<mark<<" indicates that you have passed with a distinction."<<endl;
    }
    
    if(mark<0 || mark>100){
        cout<<"Error: "<<setprecision(2)<<fixed<<mark<<" is invalid."<<endl;
    }
    
    if(!(isdigit(mark))){
        cout<<"Error: mark entered is not a number."<<endl;
    }
    
    return 0;
}
