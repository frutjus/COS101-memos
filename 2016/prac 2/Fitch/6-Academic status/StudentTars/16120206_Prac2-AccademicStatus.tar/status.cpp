#include <iostream>
using namespace std;
int main()
{
	string distinct = " you pass with distinction. \n";
	string avg = " you pass. \n";
	string redo = " you are admitted to re-exam. \n";
	string fail = " you fail. \n";
	int mark;
	cout << "Enter your mark : \n";
	cin >> mark;
	if (mark >= 75)
	{
		cout << "Congratulations! Having " << mark << distinct ;
	}
	else if ( mark > 50)
	{
		cout << "Well done. Having " << mark << avg;
	}
	else if (mark > 40)
	{
		cout << "Good attempt. Having " << mark << redo;
	}
	else if (mark < 40)
	{
		cout << "Poor effort. Having " << mark << fail;
	}
}