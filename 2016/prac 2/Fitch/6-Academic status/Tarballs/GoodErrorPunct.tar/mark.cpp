#include<iostream>
 using namespace std;
 const int  ASCORE = 75,
		BSCORE = 50,
		CSCORE = 40;

 
 int main()
 
 {
	 int mark;
	 cout << "Enter your mark:";
	 cin >> mark;
	 
	 
	if(mark > 100)
		cout << "Mark is invalid. \n";
	else if(mark < 0)
		cout << "Mark is invalid. \n";
	 else if(mark >= ASCORE)
		 cout <<"Congratulations, " <<mark<< " is a distinction! \n";
	 else if(mark>=BSCORE)
		 cout <<"The mark " <<mark<< " is a pass. \n";
	 else if(mark >= CSCORE)
		 cout <<"With the mark " <<mark<< " you qualify for a re-exam. \n";
	 else
		 cout << "Unfortunately " <<mark<< " is a fail. \n";
			
	
		 return 0;
	 
	 } 
 