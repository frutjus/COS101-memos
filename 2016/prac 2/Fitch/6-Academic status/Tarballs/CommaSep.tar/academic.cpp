// Header Files
#include <iostream>

using namespace std;

int main ()
{
  //Defining Variables
  int student_mark;

  cout << "Enter your mark: ";
  cin >> student_mark;

  //If statements.
  if (student_mark >= 75)
    {
    cout << "You have achieved " << student_mark << ", congratulations you pass with a distinction.";
    }

	   else if (student_mark >= 50 && student_mark <=74)
  	  {
   	  cout << "You have acheived " << student_mark << ", well done, you pass.";
 	    }

		    else if (student_mark >= 40 && student_mark <= 49)
  		      {
   		       cout << "Having achieved " << student_mark << " you are admitted to re-exam.";
  		      }

			       else if (student_mark < 40)
 			          {
  			        cout << "Having achieved " << student_mark << ", you have unfortunately failed.";
 			          }

return 0;

}
