#include<iostream>
#include<string>
using namespace std;

int main()

{
	int marK;
	
	cout <<"Enter your mark:";
	cin >>marK;
	if (marK <0 && marK >100)
	cout <<"Invalid grade\n"; 
	else if (marK<=100 && marK>=75)
	cout <<"Congratulations! Having "<<marK<<" you pass with distinction.\n";
	else if  (marK<=74 && marK>=50)
	cout <<"Well done. Having "<<marK<<" you pass.\n";
	else if  (marK<=49 && marK>=40)
	cout <<"You failed, but having "<<marK<<" you qualify for a re-exam.\n";
	else if  (marK<40 && marK>=0)
	cout <<"Having "<<marK<<" you failed.\n";
	
	
	return 0;
	
	
}