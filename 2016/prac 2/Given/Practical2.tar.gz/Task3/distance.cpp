#include <iostream>		
using namespace std;

const double SPEED = 120.0; 
	
int main()				
{
	return 0;
}
